// 获取app实例
let app = getApp();
// console.log(app.globalData.name)

// 引入消息提示模块文件
let {tip} = require('../../utils/tip'); 
// 使用方法
tip('温馨提示','error');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    age:20,
    hopy:'篮球'
  },

    //=====================自定义事件============================== 
      // 1.函数声明式
    user:function(){
        console.log('我是声明式函数')
        console.log(this)
    },
    // 2.ES6简写（提倡）
    users(){
        console.log('我是简写函数')
        console.log(this)
    },
    // 3.箭头函数
    userss:()=>{
        console.log('我是箭头函数')
        console.log(this)
        // 定时器  回调函数
    },  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('页面-onLoad')
    // 应用场景：1.获取页面跳转传递的参数 A(name=李四)-B（onload）
            //  2.获取网络数据（发起网络请求  使用接口）

    // 使用自定义函数
    this.user();
    this.users();
    this.userss();
  },

   /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('页面-onShow')
    // 应用场景：1.发起网络请求
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log('页面-onReady')
    // 应用场景：1.获取页面上的元素位置
  },

 

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log('页面-onHide')
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log('页面-onUnload')
  }
})