App({

//   冷启动：如果用户首次打开，或小程序销毁后被用户再次打开，此时小程序需要重新加载启动，即冷启动。
// 热启动：如果用户已经打开过某小程序，然后在一定时间内再次打开该小程序，此时小程序并未被销毁，
// 只是从后台状态进入前台状态，这个过程就是热启动。

  /**
   * 当小程序初始化完成时，会触发 onLaunch（全局只触发一次,冷启动）
   */
  onLaunch: function () {
    console.log('触发了onlaunch')
    // 应用场景：
        // 1.获取用户的场景值   
        // 2.检测用户登录   
        // 3.基础库兼容性判断（day5优化）
        // 4.记录用户的访问日志
        // 5.云开发环境初始化（day4）
    
    // 调用不存在函数
    // console.log(this);//app实例
    // this.fun();

    // 调用自定义函数
    // this.user();
    // this.users();
    // this.userss();
  },

  /**
   * 当小程序启动，或从后台进入前台显示，会触发 onShow（冷启动 热启动）
   */
  onShow: function (options) {
    console.log('触发了onShow')
  },

  /**
   * 当小程序从前台进入后台，会触发 onHide
   */
  onHide: function () {
    console.log('触发了onHide')
  },

  /**
   * 当小程序发生脚本错误，或者 api 调用失败时，会触发 onError 并带上错误信息
   */
  onError: function (msg) {
    console.log('监听到错误了',msg)
  },

  /**
   *小程序要打开的页面不存在时触发。 
   * 
  */
 onPageNotFound(){

    console.log('访问的页面不存在');
    // 帮助用户定向到存在的页面，路由跳转
    wx.reLaunch({
      url: 'pages/index/index',
    })
 },
//  =========================自定义函数=============================
  // 1.函数声明式
  user:function(){
      console.log('我是声明式函数')
      console.log(this)
  },
  // 2.ES6简写（提倡）
  users(){
    console.log('我是简写函数')
    console.log(this)
  },
  // 3.箭头函数
  userss:()=>{
    console.log('我是箭头函数')
    console.log(this)
  },
  // ====================自定义全局变量=========================
  globalData:{
    name:'李四',
    array:[1,2,3,4],
    buffer:true
  }
})
