

// 定义消息提示方法

const tip=(title,icon)=>{
    // 弹窗的api函数
    wx.showToast({
      title,
      icon
    })
}


// 导出方法
module.exports={
    tip
}